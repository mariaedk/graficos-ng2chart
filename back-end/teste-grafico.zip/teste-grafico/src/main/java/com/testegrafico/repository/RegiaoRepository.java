package com.testegrafico.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.testegrafico.entity.Regiao;

public interface RegiaoRepository extends JpaRepository<Regiao, Long>{

}
