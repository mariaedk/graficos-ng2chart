import { Regiao } from './regiao';

describe('Regiao', () => {
  it('should create an instance', () => {
    expect(new Regiao()).toBeTruthy();
  });
});
